# Email Aufräumen – Android-App

Läuft komplett lokal auf dem Handy. Kein eigener Server – die App verbindet
sich direkt mit Gmail (Google-Anmeldung) bzw. GMX (IMAP).

## Was du einmalig einrichten musst

### 1. Google Cloud Console (für Gmail)
1. https://console.cloud.google.com/ → neues Projekt
2. **Gmail API** aktivieren (APIs & Dienste → Bibliothek)
3. **OAuth-Zustimmungsbildschirm**: Typ "Extern", deine Gmail-Adresse als Testnutzer eintragen
4. **Anmeldedaten erstellen → OAuth-Client-ID → Android**
   - Paketname: `de.goerner.emailaufraeumen`
   - SHA-1-Fingerabdruck: brauchst du vom Debug-Keystore (siehe unten)

**SHA-1 herausfinden** (nachdem die APK einmal gebaut wurde, oder lokal mit Android Studio):
```
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
```
Den SHA1-Wert bei der OAuth-Client-ID in Google Cloud Console eintragen.

### 2. GitHub Repository
1. Neues Repository erstellen (z. B. "EmailAufraeumen")
2. Diesen kompletten Ordner hochladen (per GitHub-Weboberfläche: "Add file → Upload files", einfach alles reinziehen)
3. Unter **Actions** siehst du den Workflow "Build APK" automatisch laufen
4. Nach ein paar Minuten: fertige APK unter **Actions → letzter Lauf → Artifacts → email-aufraeumen-apk** herunterladen

### 3. APK installieren
1. APK aufs Handy laden (z. B. per Google Drive oder USB-Kabel)
2. In Android: Installation aus unbekannten Quellen einmalig erlauben
3. Antippen → installieren → fertig, App-Icon erscheint

### 4. GMX-App-Passwort (nur falls du GMX nutzt)
GMX-Postfach → Einstellungen → POP3/IMAP/SMTP → IMAP aktivieren, App-Passwort erstellen
(nicht dein normales Passwort verwenden).

## Wie es funktioniert

- **Gmail**: Google-Anmeldung öffnet sich direkt in der App, danach läuft alles
  über Googles offizielle Gmail-API – ohne Umweg über einen Server
- **GMX**: Du gibst Email + App-Passwort einmal ein, die App verbindet sich
  direkt per IMAP; die Zugangsdaten verlassen das Gerät nie
- "Löschen" verschiebt in den Papierkorb (wiederherstellbar), kein Hard-Delete

## Falls der Build fehlschlägt

Melde dich mit der Fehlermeldung aus dem "Actions"-Tab bei mir, dann fixe ich
das gezielt – bei Android-Projekten mit vielen Abhängigkeiten (Gmail API, IMAP)
kann es beim ersten Build kleine Versions-Konflikte geben, die sich aber
gezielt beheben lassen.
