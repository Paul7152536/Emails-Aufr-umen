package de.goerner.emailaufraeumen.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import de.goerner.emailaufraeumen.data.*

private val catColor = mapOf(
    CAT_NEWSLETTER to Color(0xFFB45309),
    CAT_ALT to Color(0xFF78716C),
    CAT_BESTELLUNG to Color(0xFF0369A1),
    CAT_WICHTIG to Color(0xFFB91C1C)
)
private val catDesc = mapOf(
    CAT_NEWSLETTER to "Automatisierte Mailings, Abo-Verteiler",
    CAT_ALT to "Alte, wahrscheinlich irrelevante Mails",
    CAT_BESTELLUNG to "Versand- & Bestellbestätigungen",
    CAT_WICHTIG to "Behörden, Bank – standardmäßig ausgeschlossen"
)
private val catOrder = listOf(CAT_NEWSLETTER, CAT_ALT, CAT_BESTELLUNG, CAT_WICHTIG)

@Composable
fun ProviderChoiceScreen(onGmail: () -> Unit, onGmx: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Welches Postfach?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Verbinde dein Postfach, um es aufzuräumen.", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onGmail, modifier = Modifier.fillMaxWidth()) { Text("Mit Gmail verbinden") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onGmx, modifier = Modifier.fillMaxWidth()) { Text("Mit GMX verbinden") }
    }
}

@Composable
fun GmxLoginScreen(onConnected: (GmxProvider) -> Unit) {
    var email by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("GMX-Zugangsdaten", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(email, { email = it }, label = { Text("deine@gmx.de") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(pw, { pw = it }, label = { Text("App-Passwort") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Text("Nutze ein GMX-App-Passwort, nicht dein Hauptpasswort (siehe README).", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = Color(0xFFB91C1C)) }
        Spacer(Modifier.height(16.dp))
        Button(
            enabled = !busy,
            onClick = {
                busy = true; error = null
                scope.launch {
                    try {
                        val p = GmxProvider(email, pw)
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { p.testLogin() }
                        onConnected(p)
                    } catch (e: Exception) {
                        error = "Login fehlgeschlagen. Prüfe E-Mail und App-Passwort."
                    } finally { busy = false }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "Verbinde..." else "Verbinden") }
    }
}

@Composable
fun DashboardScreen(vm: MainViewModel) {
    val senders by vm.senders
    val error by vm.error
    val loading by vm.loading
    val excluded by vm.excluded
    val lastResult by vm.lastResult
    var confirmDialog by remember { mutableStateOf<Pair<String, MailAction>?>(null) }
    var expanded by remember { mutableStateOf(setOf(CAT_NEWSLETTER)) }

    LaunchedEffect(Unit) { vm.scan() }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(20.dp)) {
            Text("Postfach aufräumen", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            senders?.let {
                val total = it.sumOf { s -> s.count }
                Text("$total Mails über ${it.size} Absender · nichts ohne Freigabe", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
        }

        lastResult?.let {
            Text(it, Modifier.padding(horizontal = 20.dp).padding(bottom = 8.dp), color = Color(0xFF166534))
        }
        error?.let {
            Text(it, Modifier.padding(horizontal = 20.dp).padding(bottom = 8.dp), color = Color(0xFFB91C1C))
        }

        if (loading && senders == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return
        }

        val grouped = senders.orEmpty().groupBy { it.category }

        LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(catOrder.filter { grouped.containsKey(it) }) { cat ->
                val list = grouped[cat].orEmpty()
                val active = list.filter { it.address !in excluded }
                val total = list.sumOf { it.count }
                val activeCount = active.sumOf { it.count }
                val isOpen = cat in expanded

                Card(shape = RoundedCornerShape(12.dp)) {
                    Column {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp)
                                .clickableToggle { expanded = if (isOpen) expanded - cat else expanded + cat },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("$cat · $total Mails", fontWeight = FontWeight.SemiBold)
                                Text(catDesc[cat] ?: "", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        }
                        if (isOpen) {
                            Divider()
                            list.forEach { s ->
                                val isExcl = s.address in excluded
                                Row(
                                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                                        .clickableToggle { vm.toggleExclude(s.address) },
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = !isExcl, onCheckedChange = { vm.toggleExclude(s.address) })
                                        Column {
                                            Text(s.name, style = MaterialTheme.typography.bodyMedium)
                                            Text(s.address, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                        }
                                    }
                                    Text("${s.count} Mails", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                }
                            }
                            Row(
                                Modifier.fillMaxWidth().padding(16.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
                            ) {
                                Text("$activeCount von $total ausgewählt", color = Color.Gray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                OutlinedButton(onClick = { confirmDialog = cat to MailAction.ARCHIVE }, enabled = activeCount > 0) { Text("Archivieren") }
                                Button(onClick = { confirmDialog = cat to MailAction.DELETE }, enabled = activeCount > 0) { Text("Löschen") }
                            }
                        }
                    }
                }
            }
        }
    }

    confirmDialog?.let { (cat, action) ->
        val list = grouped(senders.orEmpty())[cat].orEmpty().filter { it.address !in excluded }
        val count = list.sumOf { it.count }
        AlertDialog(
            onDismissRequest = { confirmDialog = null },
            title = { Text(if (action == MailAction.DELETE) "Wirklich löschen?" else "Wirklich archivieren?") },
            text = { Text("$count Mails aus „$cat“ werden ${if (action == MailAction.DELETE) "in den Papierkorb verschoben" else "archiviert"}.") },
            confirmButton = {
                Button(onClick = { vm.runAction(cat, action); confirmDialog = null }) { Text("Bestätigen") }
            },
            dismissButton = { TextButton(onClick = { confirmDialog = null }) { Text("Abbrechen") } }
        )
    }
}

private fun grouped(list: List<SenderGroup>) = list.groupBy { it.category }

private fun Modifier.clickableToggle(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))
