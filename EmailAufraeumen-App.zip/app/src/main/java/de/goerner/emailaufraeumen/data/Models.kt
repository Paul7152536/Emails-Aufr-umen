package de.goerner.emailaufraeumen.data

data class SenderGroup(
    val name: String,
    val address: String,
    val category: String,
    var count: Int = 0,
    var sizeMb: Double = 0.0,
    var oldestDays: Int = 0,
    val ids: MutableList<String> = mutableListOf() // Gmail: message IDs / GMX: "uid" als String
)

enum class MailAction { DELETE, ARCHIVE }

const val CAT_NEWSLETTER = "Newsletter"
const val CAT_ALT = "Sonstige alte Mails"
const val CAT_BESTELLUNG = "Bestellungen"
const val CAT_WICHTIG = "Wichtig"

fun categorize(isNewsletter: Boolean, fromEmail: String): String {
    val domain = fromEmail.substringAfter("@", "")
    return when {
        Regex("bank|sparkasse|finanzamt|steuer|amt\\.de", RegexOption.IGNORE_CASE).containsMatchIn(domain) -> CAT_WICHTIG
        Regex("amazon|dhl|hermes|dpd|versand|bestellung", RegexOption.IGNORE_CASE).containsMatchIn(domain) -> CAT_BESTELLUNG
        isNewsletter -> CAT_NEWSLETTER
        else -> CAT_ALT
    }
}
