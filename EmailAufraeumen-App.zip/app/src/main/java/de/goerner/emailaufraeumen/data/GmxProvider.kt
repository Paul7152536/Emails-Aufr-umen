package de.goerner.emailaufraeumen.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Properties
import javax.mail.*
import javax.mail.internet.InternetAddress
import javax.mail.search.FlagTerm

/**
 * Verbindet sich DIREKT vom Gerät aus per IMAP mit GMX.
 * Zugangsdaten bleiben nur im Arbeitsspeicher der App, werden nicht auf einen Server geschickt.
 */
class GmxProvider(private val email: String, private val appPassword: String) {

    private fun session(): Session {
        val props = Properties()
        props["mail.imap.host"] = "imap.gmx.net"
        props["mail.imap.port"] = "993"
        props["mail.imap.ssl.enable"] = "true"
        return Session.getInstance(props)
    }

    fun testLogin() {
        val store = session().getStore("imap")
        store.connect("imap.gmx.net", email, appPassword)
        store.close()
    }

    suspend fun scan(maxMessages: Int = 1500): List<SenderGroup> = withContext(Dispatchers.IO) {
        val groups = LinkedHashMap<String, SenderGroup>()
        val store = session().getStore("imap")
        store.connect("imap.gmx.net", email, appPassword)
        try {
            val inbox = store.getFolder("INBOX")
            inbox.open(Folder.READ_ONLY)
            val total = inbox.messageCount
            val start = maxOf(1, total - maxMessages + 1)
            val messages = inbox.getMessages(start, total)

            for (msg in messages) {
                val from = (msg.from?.getOrNull(0) as? InternetAddress) ?: continue
                val addr = from.address ?: continue
                val name = from.personal ?: addr
                val ageDays = ((System.currentTimeMillis() - (msg.sentDate?.time ?: System.currentTimeMillis())) / 86400000L).toInt()
                val isNL = msg.getHeader("List-Unsubscribe")?.isNotEmpty() == true
                val sizeMb = msg.size / 1024.0 / 1024.0

                val group = groups.getOrPut(addr) { SenderGroup(name, addr, categorize(isNL, addr)) }
                group.count++
                group.sizeMb += sizeMb
                group.oldestDays = maxOf(group.oldestDays, ageDays)
                group.ids.add((msg as com.sun.mail.imap.IMAPMessage).messageNumber.toString())
            }
            inbox.close(false)
        } finally {
            store.close()
        }
        groups.values.toList()
    }

    suspend fun applyAction(messageNumbers: List<String>, action: MailAction) = withContext(Dispatchers.IO) {
        val store = session().getStore("imap")
        store.connect("imap.gmx.net", email, appPassword)
        try {
            val inbox = store.getFolder("INBOX")
            inbox.open(Folder.READ_WRITE)
            val nums = messageNumbers.map { it.toInt() }.toIntArray()
            val msgs = inbox.getMessages(nums.min(), nums.max()).filter { it.messageNumber in nums }

            when (action) {
                MailAction.DELETE -> {
                    msgs.forEach { it.setFlag(Flags.Flag.DELETED, true) }
                }
                MailAction.ARCHIVE -> {
                    val archiveName = inbox.list().find { it.name.contains("Archiv", true) }?.name ?: "Archiv"
                    val archive = store.getFolder(archiveName)
                    if (!archive.exists()) archive.create(Folder.HOLDS_MESSAGES)
                    inbox.copyMessages(msgs.toTypedArray(), archive)
                    msgs.forEach { it.setFlag(Flags.Flag.DELETED, true) }
                }
            }
            inbox.close(true) // true = löscht als \Deleted markierte Mails endgültig aus INBOX (bei DELETE landen sie im Papierkorb-Verhalten von GMX, bei ARCHIVE wurden sie vorher kopiert)
        } finally {
            store.close()
        }
    }
}
