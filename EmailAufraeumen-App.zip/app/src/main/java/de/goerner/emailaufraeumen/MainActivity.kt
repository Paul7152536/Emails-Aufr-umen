package de.goerner.emailaufraeumen

import android.accounts.AccountManager
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import de.goerner.emailaufraeumen.data.GmailProvider
import de.goerner.emailaufraeumen.data.GmxProvider
import de.goerner.emailaufraeumen.ui.*

class MainActivity : ComponentActivity() {

    private lateinit var googleSignInLauncher: androidx.activity.result.ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(com.google.android.gms.common.api.Scope("https://www.googleapis.com/auth/gmail.modify"))
            .build()
        val signInClient = GoogleSignIn.getClient(this, gso)

        setContent {
            var screen by remember { mutableStateOf("choice") } // choice | gmxLogin | dashboard
            val vm: MainViewModel = viewModel()

            googleSignInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    val account = GoogleSignIn.getSignedInAccountFromIntent(result.data).result
                    val accountName = account?.email
                    if (accountName != null) {
                        vm.provider = Provider.Gmail(GmailProvider(this, accountName))
                        screen = "dashboard"
                    }
                }
            }

            MaterialTheme {
                Surface {
                    when (screen) {
                        "choice" -> ProviderChoiceScreen(
                            onGmail = { googleSignInLauncher.launch(signInClient.signInIntent) },
                            onGmx = { screen = "gmxLogin" }
                        )
                        "gmxLogin" -> GmxLoginScreen(onConnected = { provider ->
                            vm.provider = Provider.Gmx(provider)
                            screen = "dashboard"
                        })
                        "dashboard" -> DashboardScreen(vm)
                    }
                }
            }
        }
    }
}
