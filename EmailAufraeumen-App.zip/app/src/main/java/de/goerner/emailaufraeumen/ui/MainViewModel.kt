package de.goerner.emailaufraeumen.ui

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import de.goerner.emailaufraeumen.data.*
import kotlinx.coroutines.launch

sealed class Provider {
    data class Gmail(val provider: GmailProvider) : Provider()
    data class Gmx(val provider: GmxProvider) : Provider()
}

class MainViewModel : ViewModel() {
    var provider: Provider? = null
    val senders = mutableStateOf<List<SenderGroup>?>(null)
    val error = mutableStateOf<String?>(null)
    val loading = mutableStateOf(false)
    val excluded = mutableStateOf<Set<String>>(emptySet())
    val lastResult = mutableStateOf<String?>(null)

    fun scan() {
        val p = provider ?: return
        loading.value = true
        error.value = null
        viewModelScope.launch {
            try {
                val result = when (p) {
                    is Provider.Gmail -> p.provider.scan()
                    is Provider.Gmx -> p.provider.scan()
                }
                senders.value = result
                excluded.value = result.filter { it.category == CAT_WICHTIG }.map { it.address }.toSet()
            } catch (e: Exception) {
                error.value = "Scan fehlgeschlagen: ${e.message}"
            } finally {
                loading.value = false
            }
        }
    }

    fun toggleExclude(address: String) {
        excluded.value = if (address in excluded.value) excluded.value - address else excluded.value + address
    }

    fun runAction(category: String, action: MailAction) {
        val p = provider ?: return
        val active = senders.value.orEmpty().filter { it.category == category && it.address !in excluded.value }
        val ids = active.flatMap { it.ids }
        if (ids.isEmpty()) return
        loading.value = true
        viewModelScope.launch {
            try {
                when (p) {
                    is Provider.Gmail -> p.provider.applyAction(ids, action)
                    is Provider.Gmx -> p.provider.applyAction(ids, action)
                }
                lastResult.value = "${ids.size} Mails aus „$category“ ${if (action == MailAction.DELETE) "in den Papierkorb verschoben" else "archiviert"}."
                scan() // neu laden
            } catch (e: Exception) {
                error.value = "Aktion fehlgeschlagen: ${e.message}"
                loading.value = false
            }
        }
    }
}
