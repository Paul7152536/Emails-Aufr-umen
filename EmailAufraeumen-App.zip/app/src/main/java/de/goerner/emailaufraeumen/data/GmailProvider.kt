package de.goerner.emailaufraeumen.data

import android.accounts.Account
import android.content.Context
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.gmail.Gmail
import com.google.api.services.gmail.GmailScopes
import com.google.api.services.gmail.model.BatchModifyMessagesRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Verbindet sich DIREKT vom Gerät aus mit der Gmail API (Google Sign-In).
 * Es gibt keinen Zwischenserver - App <-> Google.
 */
class GmailProvider(private val context: Context, accountName: String) {

    private val credential: GoogleAccountCredential = GoogleAccountCredential.usingOAuth2(
        context, listOf(GmailScopes.GMAIL_MODIFY)
    ).setSelectedAccountName(accountName)

    private val service: Gmail = Gmail.Builder(
        NetHttpTransport(), GsonFactory.getDefaultInstance(), credential
    ).setApplicationName("Email Aufräumen").build()

    suspend fun scan(maxMessages: Int = 1500): List<SenderGroup> = withContext(Dispatchers.IO) {
        val groups = LinkedHashMap<String, SenderGroup>()
        var pageToken: String? = null
        var fetched = 0

        do {
            val list = service.users().messages().list("me")
                .setMaxResults(200L)
                .setPageToken(pageToken)
                .setQ("-in:sent -in:draft")
                .execute()
            val ids = list.messages ?: emptyList()

            for (m in ids) {
                if (fetched >= maxMessages) break
                val msg = service.users().messages().get("me", m.id)
                    .setFormat("metadata")
                    .setMetadataHeaders(listOf("From", "Date", "List-Unsubscribe"))
                    .execute()
                val headers = msg.payload?.headers.orEmpty()
                val from = headers.find { it.name.equals("From", true) }?.value ?: continue
                val email = Regex("<(.+?)>").find(from)?.groupValues?.get(1) ?: from
                val name = from.substringBefore("<").trim().trim('"').ifBlank { email }
                val dateHeader = headers.find { it.name.equals("Date", true) }?.value
                val ageDays = try {
                    val dateMs = java.util.Date.parse(dateHeader ?: "")
                    ((System.currentTimeMillis() - dateMs) / 86400000L).toInt()
                } catch (e: Exception) { 0 }
                val isNL = headers.any { it.name.equals("List-Unsubscribe", true) }
                val sizeMb = (msg.sizeEstimate ?: 0L) / 1024.0 / 1024.0

                val group = groups.getOrPut(email) {
                    SenderGroup(name, email, categorize(isNL, email))
                }
                group.count++
                group.sizeMb += sizeMb
                group.oldestDays = maxOf(group.oldestDays, ageDays)
                group.ids.add(m.id)
                fetched++
            }
            pageToken = list.nextPageToken
        } while (pageToken != null && fetched < maxMessages)

        groups.values.toList()
    }

    suspend fun applyAction(messageIds: List<String>, action: MailAction) = withContext(Dispatchers.IO) {
        messageIds.chunked(1000).forEach { chunk ->
            val req = BatchModifyMessagesRequest().setIds(chunk)
            when (action) {
                MailAction.DELETE -> req.addLabelIds = listOf("TRASH").also { req.removeLabelIds = listOf("INBOX") }
                MailAction.ARCHIVE -> req.removeLabelIds = listOf("INBOX")
            }
            service.users().messages().batchModify("me", req).execute()
        }
    }

    companion object {
        /** Liefert die für Gmail-Zugriff nötige OAuth-Scope-Zeichenkette für den Consent-Dialog. */
        const val SCOPE = "oauth2:https://www.googleapis.com/auth/gmail.modify"
    }
}
