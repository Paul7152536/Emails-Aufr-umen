# -*- coding: utf-8 -*-
"""
Email Aufraeumen - lokales Tool, kein Server.
Verbindet sich per IMAP direkt mit Gmail oder GMX (App-Passwort noetig,
kein OAuth/Cloud-Projekt), zeigt Absender gruppiert als "Kategorien"
und erlaubt Mehrfachauswahl + Loeschen.
"""

import imaplib
import email
from email.header import decode_header
import tkinter as tk
from tkinter import ttk, messagebox
from collections import defaultdict
import re
import threading

PROVIDERS = {
    "Gmail": {"host": "imap.gmail.com", "port": 993},
    "GMX": {"host": "imap.gmx.net", "port": 993},
}

NEWSLETTER_HINTS = [
    "newsletter", "noreply", "no-reply", "info@", "mailer", "notification",
    "notifications", "marketing", "angebot", "deals", "promo", "news@",
]


def decode_str(value):
    if not value:
        return ""
    parts = decode_header(value)
    out = ""
    for text, enc in parts:
        if isinstance(text, bytes):
            try:
                out += text.decode(enc or "utf-8", errors="ignore")
            except LookupError:
                out += text.decode("utf-8", errors="ignore")
        else:
            out += text
    return out


def extract_sender_email(raw_from):
    match = re.search(r"[\w\.\-+]+@[\w\.\-]+", raw_from or "")
    return match.group(0).lower() if match else (raw_from or "unbekannt")


class LoginFrame(ttk.Frame):
    def __init__(self, master, on_success):
        super().__init__(master, padding=20)
        self.on_success = on_success

        ttk.Label(self, text="Email Aufraeumen", font=("Segoe UI", 16, "bold")).grid(
            row=0, column=0, columnspan=2, pady=(0, 15)
        )

        ttk.Label(self, text="Anbieter:").grid(row=1, column=0, sticky="e", pady=4)
        self.provider_var = tk.StringVar(value="Gmail")
        provider_box = ttk.Combobox(
            self, textvariable=self.provider_var, values=list(PROVIDERS.keys()),
            state="readonly", width=27
        )
        provider_box.grid(row=1, column=1, pady=4)

        ttk.Label(self, text="Email-Adresse:").grid(row=2, column=0, sticky="e", pady=4)
        self.email_entry = ttk.Entry(self, width=30)
        self.email_entry.grid(row=2, column=1, pady=4)

        ttk.Label(self, text="App-Passwort:").grid(row=3, column=0, sticky="e", pady=4)
        self.pw_entry = ttk.Entry(self, width=30, show="*")
        self.pw_entry.grid(row=3, column=1, pady=4)

        hint = (
            "Hinweis: Nicht dein normales Passwort!\n"
            "Gmail: Google-Konto -> Sicherheit -> App-Passwoerter\n"
            "GMX: Einstellungen -> Sicherheit -> App-Passwort erstellen"
        )
        ttk.Label(self, text=hint, foreground="#555", justify="left", font=("Segoe UI", 8)).grid(
            row=4, column=0, columnspan=2, pady=(8, 12), sticky="w"
        )

        self.status_label = ttk.Label(self, text="", foreground="red")
        self.status_label.grid(row=6, column=0, columnspan=2)

        self.login_btn = ttk.Button(self, text="Verbinden", command=self.try_login)
        self.login_btn.grid(row=5, column=0, columnspan=2, pady=6)

    def try_login(self):
        provider = self.provider_var.get()
        addr = self.email_entry.get().strip()
        pw = self.pw_entry.get().strip()
        if not addr or not pw:
            self.status_label.config(text="Bitte Email und App-Passwort eingeben.")
            return

        self.login_btn.config(state="disabled")
        self.status_label.config(text="Verbinde...", foreground="black")

        def worker():
            try:
                cfg = PROVIDERS[provider]
                conn = imaplib.IMAP4_SSL(cfg["host"], cfg["port"])
                conn.login(addr, pw)
                self.after(0, lambda: self.on_success(conn))
            except Exception as e:
                self.after(0, lambda: self._fail(str(e)))

        threading.Thread(target=worker, daemon=True).start()

    def _fail(self, msg):
        self.login_btn.config(state="normal")
        self.status_label.config(text=f"Fehler: {msg}", foreground="red")


class CategoryFrame(ttk.Frame):
    def __init__(self, master, conn):
        super().__init__(master, padding=15)
        self.conn = conn
        self.categories = {}  # name -> {"senders": set, "uids": [], "count": int}
        self.check_vars = {}

        top = ttk.Frame(self)
        top.pack(fill="x", pady=(0, 10))
        ttk.Label(top, text="Postfach-Kategorien", font=("Segoe UI", 14, "bold")).pack(side="left")
        self.reload_btn = ttk.Button(top, text="Neu laden", command=self.load_categories)
        self.reload_btn.pack(side="right")

        self.status = ttk.Label(self, text="Lade Mails...")
        self.status.pack(anchor="w")

        self.list_frame = ttk.Frame(self)
        self.list_frame.pack(fill="both", expand=True, pady=10)

        bottom = ttk.Frame(self)
        bottom.pack(fill="x")
        self.delete_btn = ttk.Button(
            bottom, text="Ausgewaehlte Kategorien loeschen", command=self.delete_selected
        )
        self.delete_btn.pack(side="left")
        self.info_label = ttk.Label(bottom, text="")
        self.info_label.pack(side="right")

        self.load_categories()

    def classify(self, sender_email, subject, is_old):
        s = sender_email.lower()
        subj = (subject or "").lower()
        if any(h in s for h in NEWSLETTER_HINTS) or "unsubscribe" in subj:
            return "Newsletter / Werbung"
        if is_old:
            return "Alt (> 1 Jahr)"
        return "Sonstige"

    def load_categories(self):
        self.status.config(text="Lade Mails, das kann einen Moment dauern...")
        self.reload_btn.config(state="disabled")
        for w in self.list_frame.winfo_children():
            w.destroy()
        self.check_vars.clear()

        def worker():
            try:
                self.conn.select("INBOX")
                typ, data = self.conn.search(None, "ALL")
                uids = data[0].split()
                cats = defaultdict(lambda: {"count": 0, "uids": [], "senders": set()})

                import datetime
                one_year_ago = datetime.datetime.now() - datetime.timedelta(days=365)

                # Aus Performance-Gruenden nur Header abrufen, neueste zuerst,
                # max 1500 Mails betrachten
                uids = uids[::-1][:1500]

                for uid in uids:
                    typ, msg_data = self.conn.fetch(
                        uid, "(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])"
                    )
                    if not msg_data or not msg_data[0]:
                        continue
                    raw_header = msg_data[0][1]
                    msg = email.message_from_bytes(raw_header)
                    sender = extract_sender_email(decode_str(msg.get("From")))
                    subject = decode_str(msg.get("Subject"))
                    date_str = msg.get("Date")
                    is_old = False
                    try:
                        parsed_date = email.utils.parsedate_to_datetime(date_str)
                        if parsed_date and parsed_date.replace(tzinfo=None) < one_year_ago:
                            is_old = True
                    except Exception:
                        pass

                    cat = self.classify(sender, subject, is_old)
                    cats[cat]["count"] += 1
                    cats[cat]["uids"].append(uid)
                    cats[cat]["senders"].add(sender)

                self.categories = cats
                self.after(0, self.render_categories)
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Fehler", str(e)))
                self.after(0, lambda: self.reload_btn.config(state="normal"))

        threading.Thread(target=worker, daemon=True).start()

    def render_categories(self):
        self.reload_btn.config(state="normal")
        self.status.config(text=f"{sum(c['count'] for c in self.categories.values())} Mails geladen (max. 1500 neueste)")

        if not self.categories:
            ttk.Label(self.list_frame, text="Keine Mails gefunden.").pack()
            return

        header = ttk.Frame(self.list_frame)
        header.pack(fill="x", pady=(0, 4))
        ttk.Label(header, text="", width=3).pack(side="left")
        ttk.Label(header, text="Kategorie", font=("Segoe UI", 10, "bold")).pack(side="left", padx=(0, 20))

        for cat_name, info in sorted(self.categories.items(), key=lambda x: -x[1]["count"]):
            row = ttk.Frame(self.list_frame)
            row.pack(fill="x", pady=3)
            var = tk.BooleanVar(value=False)
            self.check_vars[cat_name] = var
            ttk.Checkbutton(row, variable=var).pack(side="left")
            text = f"{cat_name}  —  {info['count']} Mails  ({len(info['senders'])} Absender)"
            ttk.Label(row, text=text).pack(side="left", padx=(0, 10))
            ttk.Button(
                row, text="Absender anzeigen",
                command=lambda i=info: self.show_senders(i)
            ).pack(side="left")

    def show_senders(self, info):
        top = tk.Toplevel(self)
        top.title("Absender in dieser Kategorie")
        top.geometry("400x400")
        listbox = tk.Listbox(top)
        listbox.pack(fill="both", expand=True, padx=10, pady=10)
        for s in sorted(info["senders"]):
            listbox.insert("end", s)

    def delete_selected(self):
        selected = [name for name, var in self.check_vars.items() if var.get()]
        if not selected:
            messagebox.showinfo("Hinweis", "Bitte mindestens eine Kategorie auswaehlen.")
            return

        total = sum(self.categories[name]["count"] for name in selected)
        if not messagebox.askyesno(
            "Wirklich loeschen?",
            f"{total} Mails aus {len(selected)} Kategorie(n) werden in den Papierkorb verschoben. Fortfahren?"
        ):
            return

        self.delete_btn.config(state="disabled")

        def worker():
            try:
                for name in selected:
                    for uid in self.categories[name]["uids"]:
                        self.conn.store(uid, "+FLAGS", "\\Deleted")
                self.conn.expunge()
                self.after(0, lambda: messagebox.showinfo("Fertig", f"{total} Mails geloescht."))
                self.after(0, self.load_categories)
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("Fehler", str(e)))
            finally:
                self.after(0, lambda: self.delete_btn.config(state="normal"))

        threading.Thread(target=worker, daemon=True).start()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Email Aufraeumen")
        self.geometry("650x550")
        self.login_frame = LoginFrame(self, self.show_categories)
        self.login_frame.pack(fill="both", expand=True)

    def show_categories(self, conn):
        self.login_frame.pack_forget()
        self.cat_frame = CategoryFrame(self, conn)
        self.cat_frame.pack(fill="both", expand=True)


if __name__ == "__main__":
    app = App()
    app.mainloop()
