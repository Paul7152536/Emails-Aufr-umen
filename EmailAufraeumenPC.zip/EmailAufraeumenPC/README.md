# Email Aufraeumen

Lokales Tool zum Aufraeumen von Gmail/GMX. Kein Server, keine Cloud,
keine Anmeldedaten werden irgendwo gespeichert oder gesendet ausser
direkt an Gmail/GMX per IMAP.

## So bekommst du die fertige .exe (einmalig)

1. Dieses Projekt in ein neues GitHub-Repository hochladen (z.B. "EmailAufraeumen").
2. Im Repo oben auf "Actions" klicken -> Workflow "Build EXE" -> "Run workflow".
3. Nach ca. 1-2 Minuten unter dem fertigen Workflow-Lauf ganz unten bei
   "Artifacts" die Datei "EmailAufraeumen-exe" herunterladen (ZIP), entpacken.
4. EmailAufraeumen.exe doppelklicken - fertig, kein Python-Setup noetig.

## App-Passwort erstellen (statt normalem Passwort)

**Gmail:**
Google-Konto -> Sicherheit -> Zwei-Faktor-Authentifizierung aktivieren
(falls noch nicht aktiv) -> "App-Passwoerter" -> neues Passwort fuer
"Mail" erstellen -> das generierte Passwort im Tool eingeben.

**GMX:**
Einstellungen -> Sicherheit -> "App-Passwort erstellen" -> Passwort im
Tool eingeben.

## Nutzung

1. exe starten, Anbieter waehlen, Email + App-Passwort eingeben, "Verbinden".
2. Das Tool laedt die neuesten Mails (max. 1500) und gruppiert sie in
   Kategorien: "Newsletter / Werbung", "Alt (> 1 Jahr)", "Sonstige".
3. Kategorie(n) ankreuzen, optional "Absender anzeigen" pruefen,
   dann "Ausgewaehlte Kategorien loeschen".
4. Mails landen im Papierkorb (nicht sofort endgueltig geloescht).
